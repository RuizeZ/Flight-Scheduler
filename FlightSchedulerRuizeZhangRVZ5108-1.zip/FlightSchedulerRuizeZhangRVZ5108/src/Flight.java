
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Ruize Zhang
 */
class Flight {

    static void remove(String flight) {
        try {
            Connection connect = DriverManager.getConnection("jdbc:derby://localhost:1527/FlightSchedulerDBRuizeZhangRVZ5108", "java", "java");
            PreparedStatement stmt = connect.prepareStatement("DELETE FROM FLIGHT WHERE NAME = ?");
            stmt.setString(1, flight);
            int rs = stmt.executeUpdate();
        } catch (Exception ex) {
        }
        try {
            System.out.println("remove flight:"+flight);
            Connection connect = DriverManager.getConnection("jdbc:derby://localhost:1527/FlightSchedulerDBRuizeZhangRVZ5108", "java", "java");
            PreparedStatement stmt = connect.prepareStatement("SELECT CUSTOMER, DAY FROM BOOKINGS WHERE FLIGHT = ?");
            stmt.setString(1, flight);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                String name = rs.getString("CUSTOMER");
                System.out.println("remove name:"+name);
                Date date = rs.getDate("DAY");
                System.out.println("remove dat:"+date);
                for(int i=0;i<getFlight().length;i++){
                    System.out.println("getFlight().length:"+getFlight().length);
                    System.out.println("flight:"+getFlight()[i]);
                int seatbooked = Waitlist.SeatsStatus(getFlight()[i], date.toString());
                    System.out.println("seatbooked:"+seatbooked);
                if (seatbooked<totalseats(getFlight()[i])){
                    
                    PreparedStatement rebook = connect.prepareStatement("UPDATE  BOOKINGS SET FLIGHT = ? WHERE CUSTOMER = ? AND DAY = ?");
                    rebook.setString(1, getFlight()[i]);
                    rebook.setString(2, name);
                    rebook.setDate(3, date);
                    int rs1 = rebook.executeUpdate();
                }
                }
            }
//            System.out.println("1",FlightNameArray);
        } catch (Exception ex) {
        }
        

    }
    

    public static String[] getFlight() {
        ArrayList<String> FlightName = new ArrayList();
        try {
            Connection connect = DriverManager.getConnection("jdbc:derby://localhost:1527/FlightSchedulerDBRuizeZhangRVZ5108", "java", "java");
            Statement st = connect.createStatement();
            ResultSet rs = st.executeQuery("SELECT NAME FROM FLIGHT");
            while (rs.next()) {
                String Name = rs.getString("NAME");
                FlightName.add(Name);
            }
//            System.out.println("1",FlightNameArray);
        } catch (Exception ex) {
        }
        return FlightName.toArray(new String[0]);
    }
    
    public static void addFlight(String name, String seat){
        
        try {
            Connection connection = DriverManager.getConnection("jdbc:derby://localhost:1527/FlightSchedulerDBRuizeZhangRVZ5108","java","java");
            PreparedStatement insertNewFlight = connection.prepareStatement("INSERT INTO FLIGHT"
                    + "(NAME,SEATS) VALUES (?,?)");
            insertNewFlight.setString(1, name);
            insertNewFlight.setString(2, seat);
        int result = insertNewFlight.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }       
    }

    static int totalseats(String flight) {
        int seats=-1;
        try {
            Connection connect = DriverManager.getConnection("jdbc:derby://localhost:1527/FlightSchedulerDBRuizeZhangRVZ5108", "java", "java");
            PreparedStatement stmt = connect.prepareStatement("SELECT SEATS FROM FLIGHT WHERE NAME = ?");
            stmt.setString(1, flight);     
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                seats = rs.getInt("SEATS");
                System.out.println("total:"+seats);
            }
//            System.out.println("1",FlightNameArray);
        } catch (Exception ex) {
        }
        return seats;
    }
}
