
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Ruize Zhang
 */
class Customer {
    static String CustomerName;
    private static PreparedStatement insertNewPerson;
    private static Connection connection;
    
    public static String[] getCustomer() {
        ArrayList<String> CustomerName = new ArrayList();
        try {
            Connection connect = DriverManager.getConnection("jdbc:derby://localhost:1527/FlightSchedulerDBRuizeZhangRVZ5108", "java", "java");
            Statement st = connect.createStatement();
            ResultSet rs = st.executeQuery("SELECT NAME FROM CUSTOMER");
            while (rs.next()) {
                String Name = rs.getString("NAME");
                CustomerName.add(Name);
                System.out.println(CustomerName);
            }
//            System.out.println("1",FlightNameArray);
        } catch (Exception ex) {
        }
        return CustomerName.toArray(new String[0]);
    }
    public static void addCustomer(String name) {
        
        try {
            connection = DriverManager.getConnection("jdbc:derby://localhost:1527/FlightSchedulerDBRuizeZhangRVZ5108","java","java");
            insertNewPerson = connection.prepareStatement("INSERT INTO CUSTOMER"
                    + "(NAME) VALUES (?)");
            insertNewPerson.setString(1, name);
        int result = insertNewPerson.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }       
    }
    
}
