
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.sql.Date;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Ruize Zhang
 */
class Day {

    public static String[] getDays() {
        ArrayList<String> DateList = new ArrayList();
        try {
            Connection connect = DriverManager.getConnection("jdbc:derby://localhost:1527/FlightSchedulerDBRuizeZhangRVZ5108", "java", "java");
            Statement st = connect.createStatement();
            ResultSet rs = st.executeQuery("SELECT DATE FROM DAY");
            while (rs.next()) {
                DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
                Date date = rs.getDate("DATE");
                String stringdate = df.format(date);
                DateList.add(stringdate);
            }
        } catch (Exception ex) {

        }
            return DateList.toArray(new String[0]);
    }

    static void addDay(String date) {
         Date day = Date.valueOf(date);
        try {
            Connection connection = DriverManager.getConnection("jdbc:derby://localhost:1527/FlightSchedulerDBRuizeZhangRVZ5108","java","java");
            PreparedStatement insertNewFlight = connection.prepareStatement("INSERT INTO DAY"
                    + "(DATE) VALUES (?)");
            insertNewFlight.setDate(1, day);
        int result = insertNewFlight.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }       
    }
}
