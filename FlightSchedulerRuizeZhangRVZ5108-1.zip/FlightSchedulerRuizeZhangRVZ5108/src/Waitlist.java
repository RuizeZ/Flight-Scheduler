
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Ruize Zhang
 */
class Waitlist {

    private static String Customer;
    private static String Flight;
    private static String Day;

    public static int SeatsStatus(String Flight, String FlightDate) {
        int seatsBooked = -1;
        Date day = Date.valueOf(FlightDate);
        try {
            Connection connect = DriverManager.getConnection("jdbc:derby://localhost:1527/FlightSchedulerDBRuizeZhangRVZ5108", "java", "java");
            PreparedStatement getFlightSeats = connect.prepareStatement("select count(flight) from BOOKINGS where flight = ? and day = ?");
            getFlightSeats.setString(1, Flight);
            getFlightSeats.setDate(2, day);
            ResultSet rs = getFlightSeats.executeQuery();
            rs.next();
            seatsBooked = rs.getInt(1);

        } catch (Exception ex) {
        }
        return seatsBooked;
    }

    public static void addWaitlist(String customerName, String flightName, String flightday) {
        java.sql.Timestamp currentTimestamp = new java.sql.Timestamp(Calendar.getInstance().getTime().getTime());
        java.sql.Date day = java.sql.Date.valueOf(flightday);
        try {
            Connection connect = DriverManager.getConnection("jdbc:derby://localhost:1527/FlightSchedulerDBRuizeZhangRVZ5108", "java", "java");
            PreparedStatement insertNewWaitlist = connect.prepareStatement("INSERT INTO WAITLIST"
                    + "(CUSTOMER,FLIGHT,DAY,TIMESTMAP) VALUES (?,?,?,?)");
            insertNewWaitlist.setString(1, customerName);
            insertNewWaitlist.setString(2, flightName);
            insertNewWaitlist.setDate(3, day);
            insertNewWaitlist.setTimestamp(4, currentTimestamp);
            int result = insertNewWaitlist.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    public static String StatusByDay(String StatusDate) {
        String datastring = "";
        Date day = Date.valueOf(StatusDate);
        try {
            Connection connect = DriverManager.getConnection("jdbc:derby://localhost:1527/FlightSchedulerDBRuizeZhangRVZ5108", "java", "java");
            PreparedStatement stmt = connect.prepareStatement("SELECT CUSTOMER, FLIGHT, DAY FROM WAITLIST WHERE DAY = ?");

            stmt.setDate(1, day);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                String CustomerName = rs.getString("CUSTOMER");
                String Flight = rs.getString("FLIGHT");
                DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
                Date date = rs.getDate("DAY");
                String stringdate = df.format(date);
                datastring = datastring +  CustomerName + " " + Flight + " " + stringdate + "\r\n";
            }
        } catch (Exception ex) {
        }
        return datastring;
    }
    public static String StatusByName(String Name) {
        String datastring = "";
        try {
            Connection connect = DriverManager.getConnection("jdbc:derby://localhost:1527/FlightSchedulerDBRuizeZhangRVZ5108", "java", "java");
            PreparedStatement stmt = connect.prepareStatement("SELECT CUSTOMER, FLIGHT, DAY FROM WAITLIST WHERE CUSTOMER = ?");

            stmt.setString(1, Name);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                String CustomerName = rs.getString("CUSTOMER");
                String Flight = rs.getString("FLIGHT");
                DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
                Date date = rs.getDate("DAY");
                String stringdate = df.format(date);
                datastring = datastring +  CustomerName + " " + Flight + " " + stringdate + "\r\n";
            }
        } catch (Exception ex) {
        }
        return datastring;
    }

    static void Cancel(String name, String date) {
        Date day = Date.valueOf(date);
        try {
            Connection connect = DriverManager.getConnection("jdbc:derby://localhost:1527/FlightSchedulerDBRuizeZhangRVZ5108", "java", "java");
            PreparedStatement stmt = connect.prepareStatement("DELETE FROM WAITLIST WHERE CUSTOMER = ? AND DAY = ?");
            stmt.setString(1, name);
            stmt.setDate(2, day);
            int rs = stmt.executeUpdate();
        } catch (Exception ex) {
        }
    }

    static String UpdateFlight(String Flight,Date day) {
        String CustomerName="";
        try {
            Connection connect = DriverManager.getConnection("jdbc:derby://localhost:1527/FlightSchedulerDBRuizeZhangRVZ5108", "java", "java");
            PreparedStatement stmt = connect.prepareStatement("SELECT CUSTOMER FROM WAITLIST WHERE FLIGHT = ? AND DAY = ?");
            stmt.setString(1, Flight);
            stmt.setDate(2, day);
            ResultSet rs = stmt.executeQuery();
            while(rs.next()){
            int i = 0;
            CustomerName = rs.getString("CUSTOMER");
            System.out.println("updatename:"+CustomerName);
            deletewailist(CustomerName,Flight);
            if(i==0){
                break;
            }
            }
        } catch (Exception ex) {
        }
        return CustomerName;

    }

    static void deletewailist(String name, String flight) {
        if ("a".equals(name)){
            System.out.println("seleteflight:"+flight);
            try {
            Connection connect = DriverManager.getConnection("jdbc:derby://localhost:1527/FlightSchedulerDBRuizeZhangRVZ5108", "java", "java");
            PreparedStatement stmt = connect.prepareStatement("DELETE FROM WAITLIST WHERE FLIGHT = ?");
            stmt.setString(1, flight);
            int rs = stmt.executeUpdate();
        } catch (Exception ex) {
        }
        }else{
        try {
            Connection connect = DriverManager.getConnection("jdbc:derby://localhost:1527/FlightSchedulerDBRuizeZhangRVZ5108", "java", "java");
            PreparedStatement stmt = connect.prepareStatement("DELETE FROM WAITLIST WHERE CUSTOMER = ? AND FLIGHT = ?");
            stmt.setString(1, name);
            stmt.setString(2, flight);
            int rs = stmt.executeUpdate();
        } catch (Exception ex) {
        }
    }
    }
}
