/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Ruize Zhang
 */
class BookingEntry {

    private static String Customer;
    private static String Flight;
    private static String Day;

    public BookingEntry(String customerName, String flightName, String flightday) {
        Customer = customerName;
        Flight = flightName;
        Day = flightday;
    }

    public static String getCustomer() {
        return Customer;
    }

    public static String getFlight() {
        return Flight;
    }

    public static String getDay() {
        return Day;
    }

}
