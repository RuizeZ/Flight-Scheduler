
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Ruize Zhang
 */
class BookingQuery {

    public static void addBooking() {
        java.sql.Timestamp currentTimestamp = new java.sql.Timestamp(Calendar.getInstance().getTime().getTime());
        Date day = Date.valueOf(BookingEntry.getDay());
        try {
            Connection connection = DriverManager.getConnection("jdbc:derby://localhost:1527/FlightSchedulerDBRuizeZhangRVZ5108", "java", "java");
            PreparedStatement insertData = connection.prepareStatement("INSERT INTO BOOKINGS"
                    + "(CUSTOMER, FLIGHT, DAY, TIMESTAMP) VALUES (?,?,?,?)");
            insertData.setString(1, BookingEntry.getCustomer());
            insertData.setString(2, BookingEntry.getFlight());
            insertData.setDate(3, day);
            insertData.setTimestamp(4, currentTimestamp);
            int result = insertData.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

    }

    public static String StatusByFlightDay(String StatusFlight, String StatusDate) {
        String datastring = "";
        Date day = Date.valueOf(StatusDate);
        try {
            Connection connect = DriverManager.getConnection("jdbc:derby://localhost:1527/FlightSchedulerDBRuizeZhangRVZ5108", "java", "java");
            PreparedStatement stmt = connect.prepareStatement("SELECT CUSTOMER, FLIGHT, DAY FROM BOOKINGS WHERE FLIGHT = ? AND DAY = ?");

            stmt.setString(1, StatusFlight);
            stmt.setDate(2, day);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                String CustomerName = rs.getString("CUSTOMER");
                String Flight = rs.getString("FLIGHT");
                DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
                Date date = rs.getDate("DAY");
                String stringdate = df.format(date);
                datastring = datastring +  CustomerName + " " + Flight + " " + stringdate + "\r\n";
            }
        } catch (Exception ex) {
        }
        return datastring;

    }

    static String StatusByName(String Name) {
        String datastring = "";
        try {
            Connection connect = DriverManager.getConnection("jdbc:derby://localhost:1527/FlightSchedulerDBRuizeZhangRVZ5108", "java", "java");
            PreparedStatement stmt = connect.prepareStatement("SELECT CUSTOMER, FLIGHT, DAY FROM BOOKINGS WHERE CUSTOMER = ?");

            stmt.setString(1, Name);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                String CustomerName = rs.getString("CUSTOMER");
                String Flight = rs.getString("FLIGHT");
                DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
                Date date = rs.getDate("DAY");
                String stringdate = df.format(date);
                datastring = datastring +  CustomerName + " " + Flight + " " + stringdate + "\r\n";
            }
        } catch (Exception ex) {
        }
        return datastring;
    }
    static void Cancel(String name, String date){
        String updateCustomName;
        Date day = Date.valueOf(date);
        try {
            Connection connect = DriverManager.getConnection("jdbc:derby://localhost:1527/FlightSchedulerDBRuizeZhangRVZ5108", "java", "java");
            PreparedStatement getflight = connect.prepareStatement("SELECT FLIGHT FROM BOOKINGS WHERE CUSTOMER = ? AND DAY = ?");
            getflight.setString(1, name);
            getflight.setDate(2, day);
            ResultSet rs = getflight.executeQuery();
            while (rs.next()){
                String Flight = rs.getString("FLIGHT");
                updateCustomName = Waitlist.UpdateFlight(Flight,day);
                if (updateCustomName!=""){
                updateBooking(Flight,day,updateCustomName);
                }
            }
        } catch (Exception ex) {
        }
        try {
            Connection connect = DriverManager.getConnection("jdbc:derby://localhost:1527/FlightSchedulerDBRuizeZhangRVZ5108", "java", "java");
            PreparedStatement stmt = connect.prepareStatement("DELETE FROM BOOKINGS WHERE CUSTOMER = ? AND DAY = ?");
            stmt.setString(1, name);
            stmt.setDate(2, day);
            int rs = stmt.executeUpdate();
        } catch (Exception ex) {
        }

        
    }

    private static void updateBooking(String Flight,Date day,String name) {
        java.sql.Timestamp currentTimestamp = new java.sql.Timestamp(Calendar.getInstance().getTime().getTime());
//        Date day = Date.valueOf(BookingEntry.getDay());
        System.out.println("name:"+name);
        try {
            Connection connection = DriverManager.getConnection("jdbc:derby://localhost:1527/FlightSchedulerDBRuizeZhangRVZ5108", "java", "java");
            PreparedStatement insertData = connection.prepareStatement("INSERT INTO BOOKINGS"
                    + "(CUSTOMER, FLIGHT, DAY, TIMESTAMP) VALUES (?,?,?,?)");
            insertData.setString(1, name);
            insertData.setString(2, Flight);
            insertData.setDate(3, day);
            insertData.setTimestamp(4, currentTimestamp);
            int result = insertData.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

}
